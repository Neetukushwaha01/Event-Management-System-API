from requests import Response
from rest_framework import generics, permissions, status
from rest_framework.views import APIView
from rest_framework import status
from .models import Event
from .serializers import EventSerializer
from rest_framework.response import Response
from rest_framework import status
from rest_framework import permissions

class IsAdmin(permissions.BasePermission):

    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role == 'admin'

class IsOrganizer(permissions.BasePermission):

    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role == 'organizer'

class IsAttendee(permissions.BasePermission):

    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role == 'attendee'

class IsEventOrganizerOrAdmin(permissions.BasePermission):

    def has_object_permission(self, request, view, obj):
        return request.user == obj.creator or request.user.role == 'admin'


# 🛠 Create Event (Only Organizer & Admin)
class EventCreateView(generics.CreateAPIView):
    queryset = Event.objects.all()
    serializer_class = EventSerializer
    permission_classes = [IsAdmin | IsOrganizer]

    def perform_create(self, serializer):
        event = serializer.save(organizer=self.request.user)  # Organizer ko set karna zaroori hai
        response_data = {
            "message": "Event created successfully!",
            "event": EventSerializer(event).data
        }
        return Response(response_data, status=status.HTTP_201_CREATED)


class EventListView( APIView ):
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        events = Event.objects.all()


        if not events.exists():
            return Response( {"message": "No events available."}, status=status.HTTP_200_OK )

        serializer = EventSerializer( events, many=True )
        return Response( serializer.data, status=status.HTTP_200_OK )


class EventDetailView(generics.RetrieveAPIView):
    queryset = Event.objects.all()
    serializer_class = EventSerializer
    permission_classes = [permissions.AllowAny]

# ✏️ Update Event (Organizer who created it or Admin)
class EventUpdateView(generics.UpdateAPIView):
    queryset = Event.objects.all()
    serializer_class = EventSerializer
    permission_classes = [IsOrganizer | IsAdmin]

    def perform_update(self, serializer):
        event = self.get_object()


        if self.request.user != event.organizer and not self.request.user.is_admin:
            return Response(
                {"error": "You are not allowed to update this event."},
                status=status.HTTP_403_FORBIDDEN
            )

        serializer.save()
        return Response(
            {"message": "Event updated successfully!", "event": serializer.data},
            status=status.HTTP_200_OK
        )


class EventDeleteView( APIView ):
    permission_classes = [IsAdmin | IsOrganizer]

    def delete(self, request, pk):
        try:
            event = Event.objects.get( pk=pk )
            if request.user.role != 'admin' and request.user != event.creator:
                return Response( {"error": " You are not authorized to delete this event!"}, status=403 )

            event.delete()
            return Response( {"message": "Event deleted successfully!"}, status=200 )

        except Event.DoesNotExist:
            return Response( {"error": " Event not found!"}, status=404 )
