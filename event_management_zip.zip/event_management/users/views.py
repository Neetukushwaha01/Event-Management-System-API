
from rest_framework import generics, permissions
from .models import User
from .serializers import UserSerializer
from .permissions import IsAdmin


class UserListView(generics.ListAPIView):
    serializer_class = UserSerializer

    def get_queryset(self):
        return User.objects.all()

    def get_permissions(self):
        return [IsAdmin()]

class UserCreateView(generics.CreateAPIView):
    serializer_class = UserSerializer

    def get_permissions(self):

        return [permissions.AllowAny()]

class UserDetailView(generics.RetrieveAPIView):
    serializer_class = UserSerializer

    def get_queryset(self):
        return User.objects.all()

    def get_permissions(self):
        return [IsAdmin()]


class UserUpdateView(generics.UpdateAPIView):
    serializer_class = UserSerializer

    def get_queryset(self):
        return User.objects.all()

    def get_permissions(self):
        return [IsAdmin()]

class UserDeleteView(generics.DestroyAPIView):
    serializer_class = UserSerializer

    def get_queryset(self):
        return User.objects.all()

    def get_permissions(self):
        return [IsAdmin()]
